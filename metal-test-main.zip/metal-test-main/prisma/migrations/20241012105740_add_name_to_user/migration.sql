-- AlterTable
ALTER TABLE "User" ADD COLUMN "name" TEXT;
