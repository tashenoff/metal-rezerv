-- AlterTable
ALTER TABLE "User" ADD COLUMN "companyBIN" TEXT;
ALTER TABLE "User" ADD COLUMN "companyName" TEXT;
