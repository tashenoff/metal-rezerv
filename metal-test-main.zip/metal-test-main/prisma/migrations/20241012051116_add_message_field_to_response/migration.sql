-- AlterTable
ALTER TABLE "Response" ADD COLUMN "message" TEXT;
