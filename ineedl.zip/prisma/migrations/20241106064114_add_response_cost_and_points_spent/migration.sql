/*
  Warnings:

  - Added the required column `pointsSpent` to the `Response` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `Listing` ADD COLUMN `responseCost` INTEGER NOT NULL DEFAULT 10;

-- AlterTable
ALTER TABLE `Response` ADD COLUMN `pointsSpent` INTEGER NOT NULL;
