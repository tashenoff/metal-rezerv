/*
  Warnings:

  - You are about to drop the column `pointsSpent` on the `Response` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `Response` DROP COLUMN `pointsSpent`;

-- CreateTable
CREATE TABLE `PointsSpent` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `userId` INTEGER NOT NULL,
    `responseId` INTEGER NOT NULL,
    `pointsUsed` INTEGER NOT NULL,
    `spentAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `PointsSpent` ADD CONSTRAINT `PointsSpent_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `PointsSpent` ADD CONSTRAINT `PointsSpent_responseId_fkey` FOREIGN KEY (`responseId`) REFERENCES `Response`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
