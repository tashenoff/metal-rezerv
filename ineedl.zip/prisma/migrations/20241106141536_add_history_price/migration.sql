-- CreateTable
CREATE TABLE `PointsPrice` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `price` INTEGER NOT NULL,
    `validFrom` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `validUntil` DATETIME(3) NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `PointPriceHistory` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `pointsPriceId` INTEGER NOT NULL,
    `oldPrice` INTEGER NOT NULL,
    `newPrice` INTEGER NOT NULL,
    `changedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `changedBy` VARCHAR(191) NOT NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `PointsStatistics` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `period` VARCHAR(191) NOT NULL,
    `totalPointsAdded` INTEGER NOT NULL,
    `totalPointsSpent` INTEGER NOT NULL,
    `statisticsDate` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `PointPriceHistory` ADD CONSTRAINT `PointPriceHistory_pointsPriceId_fkey` FOREIGN KEY (`pointsPriceId`) REFERENCES `PointsPrice`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
