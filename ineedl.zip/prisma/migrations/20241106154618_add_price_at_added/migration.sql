-- AlterTable
ALTER TABLE `PointsAdded` ADD COLUMN `priceAtAdded` INTEGER NULL;
